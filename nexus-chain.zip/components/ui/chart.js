export class Chart {
  constructor(ctx, config) {
    return new window.Chart(ctx, config)
  }
}
