import { Chart } from "@/components/ui/chart"
document.addEventListener("DOMContentLoaded", () => {
  // Countdown Timer (same as main.js)
  function updateCountdown() {
    // Set the countdown to 10 hours from now
    const now = new Date()
    const launchTime = new Date(now.getTime() + 10 * 60 * 60 * 1000)

    const currentTime = new Date().getTime()
    const distance = launchTime - currentTime

    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60))
    const seconds = Math.floor((distance % (1000 * 60)) / 1000)

    document.getElementById("hours").textContent = hours.toString().padStart(2, "0")
    document.getElementById("minutes").textContent = minutes.toString().padStart(2, "0")
    document.getElementById("seconds").textContent = seconds.toString().padStart(2, "0")

    if (distance < 0) {
      clearInterval(countdownInterval)
      document.getElementById("countdown").innerHTML = "LANCIATO!"
    }
  }

  updateCountdown()
  const countdownInterval = setInterval(updateCountdown, 1000)

  // Login Form Handling
  const loginForm = document.getElementById("login-form")
  const loginContainer = document.getElementById("login-container")
  const dashboardContainer = document.getElementById("dashboard-container")
  const loginMessage = document.getElementById("login-message")

  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      e.preventDefault()

      const username = document.getElementById("username").value
      const password = document.getElementById("password").value

      // Check credentials (hardcoded for demo)
      if (username === "Nexus" && password === "Mamma1997!") {
        loginContainer.style.display = "none"
        dashboardContainer.style.display = "flex"

        // Store login state in session storage
        sessionStorage.setItem("loggedIn", "true")
      } else {
        loginMessage.textContent = "Credenziali non valide. Riprova."

        // Clear the message after 3 seconds
        setTimeout(() => {
          loginMessage.textContent = ""
        }, 3000)
      }
    })
  }

  // Check if user is already logged in
  if (sessionStorage.getItem("loggedIn") === "true" && loginContainer && dashboardContainer) {
    loginContainer.style.display = "none"
    dashboardContainer.style.display = "flex"
  }

  // Logout Button
  const logoutBtn = document.getElementById("logout-btn")
  if (logoutBtn) {
    logoutBtn.addEventListener("click", (e) => {
      e.preventDefault()

      // Clear login state
      sessionStorage.removeItem("loggedIn")

      // Redirect to login
      if (loginContainer && dashboardContainer) {
        dashboardContainer.style.display = "none"
        loginContainer.style.display = "flex"
      }
    })
  }

  // Sidebar Toggle on Mobile
  const sidebarToggle = document.getElementById("sidebar-toggle")
  const sidebar = document.querySelector(".sidebar")

  if (sidebarToggle && sidebar) {
    sidebarToggle.addEventListener("click", () => {
      sidebar.classList.toggle("active")
    })
  }

  // Dashboard Navigation
  const navLinks = document.querySelectorAll(".sidebar-nav a[data-section]")
  const sections = document.querySelectorAll(".dashboard-section")
  const sectionTitle = document.getElementById("section-title")

  navLinks.forEach((link) => {
    link.addEventListener("click", function (e) {
      e.preventDefault()

      const targetSection = this.getAttribute("data-section")

      // Update active link
      navLinks.forEach((link) => link.parentElement.classList.remove("active"))
      this.parentElement.classList.add("active")

      // Show target section
      sections.forEach((section) => section.classList.remove("active"))
      document.getElementById(`${targetSection}-section`).classList.add("active")

      // Update section title
      if (sectionTitle) {
        sectionTitle.textContent = this.querySelector("span").textContent
      }

      // Close sidebar on mobile
      if (window.innerWidth < 768 && sidebar.classList.contains("active")) {
        sidebar.classList.remove("active")
      }
    })
  })

  // Content Tabs
  const tabButtons = document.querySelectorAll(".tab-btn")

  tabButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const tabGroup = this.parentElement
      const tabContents = tabGroup.parentElement.querySelectorAll(".tab-content")
      const targetTab = this.getAttribute("data-tab")

      // Update active tab button
      tabGroup.querySelectorAll(".tab-btn").forEach((btn) => btn.classList.remove("active"))
      this.classList.add("active")

      // Show target tab content
      tabContents.forEach((content) => content.classList.remove("active"))
      document.getElementById(`${targetTab}-tab`).classList.add("active")
    })
  })

  // Chart Period Buttons
  const chartPeriodButtons = document.querySelectorAll(".btn-chart")

  chartPeriodButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const buttonGroup = this.parentElement

      // Update active button
      buttonGroup.querySelectorAll(".btn-chart").forEach((btn) => btn.classList.remove("active"))
      this.classList.add("active")

      // In a real app, this would update the chart data
      // For demo purposes, we'll just simulate a loading state
      const chart = this.closest(".chart-container").querySelector(".chart")
      chart.style.opacity = "0.5"

      setTimeout(() => {
        chart.style.opacity = "1"
      }, 500)
    })
  })

  // Create Dashboard Charts
  function createDashboardCharts() {
    // Network Activity Chart
    const networkActivityChart = document.getElementById("networkActivityChart")
    if (networkActivityChart) {
      const ctx = networkActivityChart.getContext("2d")

      // Generate random data
      const generateData = (count, min, max) => {
        return Array.from({ length: count }, () => Math.floor(Math.random() * (max - min + 1) + min))
      }

      const labels = Array.from({ length: 24 }, (_, i) => `${i}:00`)

      new Chart(ctx, {
        type: "line",
        data: {
          labels: labels,
          datasets: [
            {
              label: "Transazioni",
              data: generateData(24, 50, 200),
              borderColor: "#00f0ff",
              backgroundColor: "rgba(0, 240, 255, 0.1)",
              tension: 0.4,
              fill: true,
            },
            {
              label: "Utenti Attivi",
              data: generateData(24, 20, 100),
              borderColor: "#ff00e6",
              backgroundColor: "rgba(255, 0, 230, 0.1)",
              tension: 0.4,
              fill: true,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            x: {
              grid: {
                color: "rgba(255, 255, 255, 0.05)",
              },
              ticks: {
                color: "rgba(255, 255, 255, 0.7)",
              },
            },
            y: {
              grid: {
                color: "rgba(255, 255, 255, 0.05)",
              },
              ticks: {
                color: "rgba(255, 255, 255, 0.7)",
              },
            },
          },
          plugins: {
            legend: {
              labels: {
                color: "rgba(255, 255, 255, 0.7)",
              },
            },
          },
        },
      })
    }

    // Node Distribution Chart
    const nodeDistributionChart = document.getElementById("nodeDistributionChart")
    if (nodeDistributionChart) {
      const ctx = nodeDistributionChart.getContext("2d")

      new Chart(ctx, {
        type: "doughnut",
        data: {
          labels: ["Europa", "Nord America", "Asia", "Sud America", "Oceania", "Africa"],
          datasets: [
            {
              data: [35, 25, 20, 10, 5, 5],
              backgroundColor: ["#00f0ff", "#7b00ff", "#ff00e6", "#00c8d4", "#5900bd", "#c800b6"],
              borderWidth: 0,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: "right",
              labels: {
                color: "rgba(255, 255, 255, 0.7)",
              },
            },
          },
          cutout: "60%",
        },
      })
    }

    // Site Traffic Chart
    const siteTrafficChart = document.getElementById("siteTrafficChart")
    if (siteTrafficChart) {
      const ctx = siteTrafficChart.getContext("2d")

      const labels = ["Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago"]

      new Chart(ctx, {
        type: "line",
        data: {
          labels: labels,
          datasets: [
            {
              label: "Visite",
              data: [1200, 1900, 3000, 5000, 8000, 12000, 15000, 12458],
              borderColor: "#00f0ff",
              backgroundColor: "rgba(0, 240, 255, 0.1)",
              tension: 0.4,
              fill: true,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            x: {
              grid: {
                color: "rgba(255, 255, 255, 0.05)",
              },
              ticks: {
                color: "rgba(255, 255, 255, 0.7)",
              },
            },
            y: {
              grid: {
                color: "rgba(255, 255, 255, 0.05)",
              },
              ticks: {
                color: "rgba(255, 255, 255, 0.7)",
              },
            },
          },
          plugins: {
            legend: {
              labels: {
                color: "rgba(255, 255, 255, 0.7)",
              },
            },
          },
        },
      })
    }

    // Traffic Sources Chart
    const trafficSourcesChart = document.getElementById("trafficSourcesChart")
    if (trafficSourcesChart) {
      const ctx = trafficSourcesChart.getContext("2d")

      new Chart(ctx, {
        type: "pie",
        data: {
          labels: ["Ricerca Organica", "Social Media", "Referral", "Diretto", "Email"],
          datasets: [
            {
              data: [45, 25, 15, 10, 5],
              backgroundColor: ["#00f0ff", "#7b00ff", "#ff00e6", "#00c8d4", "#5900bd"],
              borderWidth: 0,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: "right",
              labels: {
                color: "rgba(255, 255, 255, 0.7)",
              },
            },
          },
        },
      })
    }

    // Devices Chart
    const devicesChart = document.getElementById("devicesChart")
    if (devicesChart) {
      const ctx = devicesChart.getContext("2d")

      new Chart(ctx, {
        type: "bar",
        data: {
          labels: ["Desktop", "Mobile", "Tablet"],
          datasets: [
            {
              label: "Visite",
              data: [5200, 6100, 1158],
              backgroundColor: ["#00f0ff", "#7b00ff", "#ff00e6"],
              borderWidth: 0,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            x: {
              grid: {
                color: "rgba(255, 255, 255, 0.05)",
              },
              ticks: {
                color: "rgba(255, 255, 255, 0.7)",
              },
            },
            y: {
              grid: {
                color: "rgba(255, 255, 255, 0.05)",
              },
              ticks: {
                color: "rgba(255, 255, 255, 0.7)",
              },
            },
          },
          plugins: {
            legend: {
              display: false,
            },
          },
        },
      })
    }
  }

  createDashboardCharts()

  // Create Blockchain Visualization
  function createBlockchainVisualization() {
    const chainBlocks = document.querySelector(".chain-blocks")
    if (!chainBlocks) return

    // Clear existing blocks
    chainBlocks.innerHTML = ""

    // Create blocks
    for (let i = 0; i < 20; i++) {
      const block = document.createElement("div")
      block.className = "chain-block"
      block.style.width = "80px"
      block.style.height = "80px"
      block.style.backgroundColor = "rgba(0, 240, 255, 0.1)"
      block.style.border = "1px solid rgba(0, 240, 255, 0.3)"
      block.style.borderRadius = "8px"
      block.style.margin = "0 15px"
      block.style.display = "flex"
      block.style.justifyContent = "center"
      block.style.alignItems = "center"
      block.style.fontSize = "0.8rem"
      block.style.color = "rgba(255, 255, 255, 0.7)"
      block.textContent = `#${8732 - i}`

      // Add connecting line
      if (i < 19) {
        const line = document.createElement("div")
        line.style.width = "15px"
        line.style.height = "2px"
        line.style.backgroundColor = "rgba(0, 240, 255, 0.5)"
        chainBlocks.appendChild(line)
      }

      chainBlocks.appendChild(block)
    }
  }

  createBlockchainVisualization()

  // Form Submissions
  const forms = document.querySelectorAll(".settings-form")

  forms.forEach((form) => {
    form.addEventListener("submit", function (e) {
      e.preventDefault()

      // Simulate form submission
      const submitButton = this.querySelector('button[type="submit"]')
      const originalText = submitButton.textContent

      submitButton.disabled = true
      submitButton.textContent = "Salvataggio..."

      setTimeout(() => {
        submitButton.textContent = "Salvato!"

        setTimeout(() => {
          submitButton.disabled = false
          submitButton.textContent = originalText
        }, 2000)
      }, 1500)
    })
  })

  // Copy API Key Button
  const copyButtons = document.querySelectorAll(".copy-btn")

  copyButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const input = this.previousElementSibling
      input.select()
      document.execCommand("copy")

      // Show feedback
      const originalIcon = this.innerHTML
      this.innerHTML = '<i class="fas fa-check"></i>'

      setTimeout(() => {
        this.innerHTML = originalIcon
      }, 2000)
    })
  })
})
