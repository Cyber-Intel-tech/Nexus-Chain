import { Chart } from "@/components/ui/chart"
document.addEventListener("DOMContentLoaded", () => {
  // Countdown Timer
  function updateCountdown() {
    // Set the countdown to 10 hours from now
    const now = new Date()
    const launchTime = new Date(now.getTime() + 10 * 60 * 60 * 1000)

    const currentTime = new Date().getTime()
    const distance = launchTime - currentTime

    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60))
    const seconds = Math.floor((distance % (1000 * 60)) / 1000)

    document.getElementById("hours").textContent = hours.toString().padStart(2, "0")
    document.getElementById("minutes").textContent = minutes.toString().padStart(2, "0")
    document.getElementById("seconds").textContent = seconds.toString().padStart(2, "0")

    if (distance < 0) {
      clearInterval(countdownInterval)
      document.getElementById("countdown").innerHTML = "LANCIATO!"
    }
  }

  updateCountdown()
  const countdownInterval = setInterval(updateCountdown, 1000)

  // Mobile Menu Toggle
  const hamburger = document.querySelector(".hamburger")
  const menu = document.querySelector(".menu")

  if (hamburger && menu) {
    hamburger.addEventListener("click", function () {
      this.classList.toggle("active")
      menu.classList.toggle("active")
    })
  }

  // Smooth Scrolling for Anchor Links
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault()

      const targetId = this.getAttribute("href")
      if (targetId === "#") return

      const targetElement = document.querySelector(targetId)
      if (targetElement) {
        const headerOffset = 100
        const elementPosition = targetElement.getBoundingClientRect().top
        const offsetPosition = elementPosition + window.pageYOffset - headerOffset

        window.scrollTo({
          top: offsetPosition,
          behavior: "smooth",
        })

        // Close mobile menu if open
        if (hamburger && hamburger.classList.contains("active")) {
          hamburger.classList.remove("active")
          menu.classList.remove("active")
        }
      }
    })
  })

  // Tokenomics Chart
  const tokenomicsChartElement = document.getElementById("tokenomicsChart")
  if (tokenomicsChartElement) {
    const ctx = tokenomicsChartElement.getContext("2d")
    new Chart(ctx, {
      type: "doughnut",
      data: {
        labels: [
          "Comunità e Adozione",
          "Sviluppo Ecosistema",
          "Team e Fondatori",
          "Riserva Strategica",
          "Liquidità di Mercato",
          "Consulenti e Partner",
        ],
        datasets: [
          {
            data: [40, 20, 15, 10, 10, 5],
            backgroundColor: ["#00f0ff", "#7b00ff", "#ff00e6", "#00c8d4", "#5900bd", "#c800b6"],
            borderWidth: 0,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: "right",
            labels: {
              color: "#ffffff",
              font: {
                family: "'Rajdhani', sans-serif",
                size: 14,
              },
              padding: 20,
            },
          },
          tooltip: {
            backgroundColor: "rgba(10, 10, 20, 0.8)",
            titleFont: {
              family: "'Rajdhani', sans-serif",
              size: 16,
            },
            bodyFont: {
              family: "'Rajdhani', sans-serif",
              size: 14,
            },
            callbacks: {
              label: (context) => context.label + ": " + context.raw + "%",
            },
          },
        },
        cutout: "60%",
      },
    })
  }

  // Animate elements on scroll
  const animateOnScroll = () => {
    const elements = document.querySelectorAll(".devzone-card, .roadmap-item, .tokenomics-card")

    elements.forEach((element) => {
      const elementPosition = element.getBoundingClientRect().top
      const windowHeight = window.innerHeight

      if (elementPosition < windowHeight - 100) {
        element.classList.add("animated")
      }
    })
  }

  window.addEventListener("scroll", animateOnScroll)
  animateOnScroll() // Run once on page load

  // Newsletter Form Submission
  const newsletterForm = document.getElementById("newsletter-form")
  if (newsletterForm) {
    newsletterForm.addEventListener("submit", function (e) {
      e.preventDefault()

      const emailInput = this.querySelector('input[type="email"]')
      const email = emailInput.value

      if (email) {
        // Simulate form submission
        const button = this.querySelector("button")
        const originalText = button.textContent

        button.disabled = true
        button.textContent = "Invio in corso..."

        setTimeout(() => {
          emailInput.value = ""
          button.textContent = "Iscritto!"

          setTimeout(() => {
            button.disabled = false
            button.textContent = originalText
          }, 2000)
        }, 1500)
      }
    })
  }

  // Create DNA animation in the background
  function createDNAAnimation() {
    const dnaBackground = document.querySelector(".dna-background")
    if (!dnaBackground) return

    // Create DNA strands
    for (let i = 0; i < 5; i++) {
      const strand = document.createElement("div")
      strand.className = "dna-strand"
      strand.style.left = `${Math.random() * 100}%`
      strand.style.animationDelay = `${Math.random() * 5}s`

      for (let j = 0; j < 20; j++) {
        const nucleotide = document.createElement("div")
        nucleotide.className = "nucleotide"
        strand.appendChild(nucleotide)
      }

      dnaBackground.appendChild(strand)
    }
  }

  createDNAAnimation()
})
