document.addEventListener("DOMContentLoaded", () => {
  // Metaverse Scene
  const metaverseScene = document.getElementById("metaverse-scene")
  if (!metaverseScene) return

  let scene, camera, renderer
  const blocks = []
  const connections = []
  let raycaster, mouse
  let hoveredBlock = null
  let selectedBlock = null
  const clock = new THREE.Clock()
  let frameId

  // Initialize Three.js scene
  function initMetaverse() {
    // Create scene
    scene = new THREE.Scene()

    // Create camera
    camera = new THREE.PerspectiveCamera(75, metaverseScene.clientWidth / metaverseScene.clientHeight, 0.1, 1000)
    camera.position.z = 150

    // Create renderer
    renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true })
    renderer.setSize(metaverseScene.clientWidth, metaverseScene.clientHeight)
    renderer.setClearColor(0x000000, 0)
    metaverseScene.appendChild(renderer.domElement)

    // Create raycaster for interaction
    raycaster = new THREE.Raycaster()
    mouse = new THREE.Vector2()

    // Add event listeners
    metaverseScene.addEventListener("mousemove", onMouseMove)
    metaverseScene.addEventListener("click", onMouseClick)

    // Create blockchain visualization
    createBlockchain()

    // Add ambient light
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5)
    scene.add(ambientLight)

    // Add directional light
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1)
    directionalLight.position.set(1, 1, 1)
    scene.add(directionalLight)

    // Start animation
    animate()

    // Handle window resize
    window.addEventListener("resize", onWindowResize)
  }

  // Create blockchain visualization
  function createBlockchain() {
    const blockCount = 30
    const blockSpacing = 20

    // Create blocks
    for (let i = 0; i < blockCount; i++) {
      // Create block geometry and material
      const blockGeometry = new THREE.BoxGeometry(10, 10, 10)
      const blockMaterial = new THREE.MeshPhongMaterial({
        color: 0xffd700,
        emissive: 0x996515,
        shininess: 100,
        specular: 0xffffff,
      })

      // Create block mesh
      const block = new THREE.Mesh(blockGeometry, blockMaterial)

      // Position block in a spiral pattern
      const angle = i * 0.2
      const radius = 30 + i * 0.5
      const x = Math.cos(angle) * radius
      const y = Math.sin(angle) * radius
      const z = -i * 2

      block.position.set(x, y, z)
      block.userData = { id: i, type: "block" }

      // Add block to scene and blocks array
      scene.add(block)
      blocks.push(block)

      // Create connection to previous block
      if (i > 0) {
        const prevBlock = blocks[i - 1]

        // Create connection geometry and material
        const connectionMaterial = new THREE.LineBasicMaterial({
          color: 0x00ffcc,
          linewidth: 2,
        })

        const connectionGeometry = new THREE.BufferGeometry().setFromPoints([
          new THREE.Vector3(prevBlock.position.x, prevBlock.position.y, prevBlock.position.z),
          new THREE.Vector3(block.position.x, block.position.y, block.position.z),
        ])

        const connection = new THREE.Line(connectionGeometry, connectionMaterial)
        connection.userData = { from: i - 1, to: i, type: "connection" }

        // Add connection to scene and connections array
        scene.add(connection)
        connections.push(connection)
      }
    }
  }

  // Handle mouse move
  function onMouseMove(event) {
    // Calculate mouse position in normalized device coordinates
    const rect = metaverseScene.getBoundingClientRect()
    mouse.x = ((event.clientX - rect.left) / metaverseScene.clientWidth) * 2 - 1
    mouse.y = -((event.clientY - rect.top) / metaverseScene.clientHeight) * 2 + 1

    // Update raycaster
    raycaster.setFromCamera(mouse, camera)

    // Check for intersections with blocks
    const intersects = raycaster.intersectObjects(blocks)

    // Reset previously hovered block
    if (hoveredBlock && (!intersects.length || intersects[0].object !== hoveredBlock)) {
      hoveredBlock.material.emissive.setHex(0x996515)
      hoveredBlock = null
      document.body.style.cursor = "default"
    }

    // Set new hovered block
    if (intersects.length && intersects[0].object !== hoveredBlock) {
      hoveredBlock = intersects[0].object
      hoveredBlock.material.emissive.setHex(0xff9900)
      document.body.style.cursor = "pointer"
    }
  }

  // Handle mouse click
  function onMouseClick(event) {
    // Check for intersections with blocks
    raycaster.setFromCamera(mouse, camera)
    const intersects = raycaster.intersectObjects(blocks)

    // Reset previously selected block
    if (selectedBlock) {
      selectedBlock.material.color.setHex(0xffd700)
      selectedBlock = null
    }

    // Set new selected block
    if (intersects.length) {
      selectedBlock = intersects[0].object
      selectedBlock.material.color.setHex(0xff0000)

      // Show block info (in a real app, this would display block details)
      console.log(`Block #${selectedBlock.userData.id} selected`)
    }
  }

  // Animation loop
  function animate() {
    frameId = requestAnimationFrame(animate)

    const delta = clock.getDelta()

    // Rotate camera around the scene
    const time = clock.getElapsedTime() * 0.1
    camera.position.x = Math.sin(time) * 150
    camera.position.z = Math.cos(time) * 150
    camera.lookAt(scene.position)

    // Animate blocks
    blocks.forEach((block, index) => {
      block.rotation.x += 0.005
      block.rotation.y += 0.01

      // Pulse effect
      const pulse = Math.sin(time * 5 + index) * 0.1 + 1
      block.scale.set(pulse, pulse, pulse)
    })

    // Render scene
    renderer.render(scene, camera)
  }

  // Handle window resize
  function onWindowResize() {
    camera.aspect = metaverseScene.clientWidth / metaverseScene.clientHeight
    camera.updateProjectionMatrix()
    renderer.setSize(metaverseScene.clientWidth, metaverseScene.clientHeight)
  }

  // Clean up on page change
  function cleanUp() {
    cancelAnimationFrame(frameId)
    metaverseScene.removeEventListener("mousemove", onMouseMove)
    metaverseScene.removeEventListener("click", onMouseClick)
    window.removeEventListener("resize", onWindowResize)

    // Remove all objects from scene
    while (scene.children.length > 0) {
      scene.remove(scene.children[0])
    }

    // Remove renderer
    if (renderer) {
      renderer.dispose()
      metaverseScene.removeChild(renderer.domElement)
    }
  }

  // Initialize metaverse scene
  initMetaverse()

  // Clean up on page unload
  window.addEventListener("beforeunload", cleanUp)
})
