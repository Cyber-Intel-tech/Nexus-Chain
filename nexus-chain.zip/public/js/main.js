import { Chart } from "@/components/ui/chart"
document.addEventListener("DOMContentLoaded", () => {
  // Preloader
  setTimeout(() => {
    const preloader = document.querySelector(".preloader")
    preloader.classList.add("fade-out")
    setTimeout(() => {
      preloader.style.display = "none"
    }, 500)
  }, 2000)

  // Countdown Timer
  function updateCountdown() {
    // Set the countdown to 10 hours from now
    const now = new Date()
    const launchTime = new Date(now.getTime() + 10 * 60 * 60 * 1000)

    const currentTime = new Date().getTime()
    const distance = launchTime - currentTime

    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60))
    const seconds = Math.floor((distance % (1000 * 60)) / 1000)

    document.getElementById("hours").textContent = hours.toString().padStart(2, "0")
    document.getElementById("minutes").textContent = minutes.toString().padStart(2, "0")
    document.getElementById("seconds").textContent = seconds.toString().padStart(2, "0")

    if (distance < 0) {
      clearInterval(countdownInterval)
      document.getElementById("countdown").innerHTML = "LANCIATO!"
    }
  }

  updateCountdown()
  const countdownInterval = setInterval(updateCountdown, 1000)

  // Mobile Menu Toggle
  const menuToggle = document.getElementById("menuToggle")
  const navLinks = document.getElementById("navLinks")

  if (menuToggle && navLinks) {
    menuToggle.addEventListener("click", function () {
      this.classList.toggle("active")
      navLinks.classList.toggle("active")
    })
  }

  // Smooth Scrolling for Anchor Links
  document.querySelectorAll("a[data-scroll]").forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault()

      const targetId = this.getAttribute("href")
      if (targetId === "#") return

      const targetElement = document.querySelector(targetId)
      if (targetElement) {
        const headerOffset = 100
        const elementPosition = targetElement.getBoundingClientRect().top
        const offsetPosition = elementPosition + window.pageYOffset - headerOffset

        window.scrollTo({
          top: offsetPosition,
          behavior: "smooth",
        })

        // Close mobile menu if open
        if (menuToggle && menuToggle.classList.contains("active")) {
          menuToggle.classList.remove("active")
          navLinks.classList.remove("active")
        }
      }
    })
  })

  // Tokenomics Chart
  const tokenomicsChart = document.getElementById("tokenomicsChart")
  if (tokenomicsChart) {
    new Chart(tokenomicsChart, {
      type: "doughnut",
      data: {
        labels: [
          "Community & Ecosystem",
          "Development Fund",
          "Team & Founders",
          "Strategic Reserve",
          "Market Liquidity",
          "Advisors & Partners",
        ],
        datasets: [
          {
            data: [40, 20, 15, 10, 10, 5],
            backgroundColor: [
              "#ffd700", // Gold
              "#00ffcc", // Cyan
              "#9932cc", // Purple
              "#d4af37", // Darker Gold
              "#00ccaa", // Darker Cyan
              "#7b2cbf", // Darker Purple
            ],
            borderWidth: 0,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: "right",
            labels: {
              color: "#ffffff",
              font: {
                family: "'Rajdhani', sans-serif",
                size: 14,
              },
              padding: 20,
            },
          },
          tooltip: {
            backgroundColor: "rgba(10, 10, 20, 0.8)",
            titleFont: {
              family: "'Rajdhani', sans-serif",
              size: 16,
            },
            bodyFont: {
              family: "'Rajdhani', sans-serif",
              size: 14,
            },
            callbacks: {
              label: (context) => context.label + ": " + context.raw + "%",
            },
          },
        },
        cutout: "60%",
      },
    })
  }

  // Metaverse Modal
  const enterMetaverseBtn = document.getElementById("enter-metaverse")
  const metaverseModal = document.getElementById("metaverseModal")
  const registerModal = document.getElementById("registerModal")
  const closeModalBtns = document.querySelectorAll(".close-modal")
  const registerMetaverseBtn = document.getElementById("register-metaverse")

  if (enterMetaverseBtn && metaverseModal) {
    enterMetaverseBtn.addEventListener("click", (e) => {
      e.preventDefault()
      metaverseModal.style.display = "flex"
    })
  }

  if (registerMetaverseBtn && registerModal) {
    registerMetaverseBtn.addEventListener("click", () => {
      metaverseModal.style.display = "none"
      registerModal.style.display = "flex"
    })
  }

  closeModalBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      metaverseModal.style.display = "none"
      registerModal.style.display = "none"
    })
  })

  window.addEventListener("click", (e) => {
    if (e.target === metaverseModal) {
      metaverseModal.style.display = "none"
    }
    if (e.target === registerModal) {
      registerModal.style.display = "none"
    }
  })

  // Form Submissions
  const metaverseLoginForm = document.getElementById("metaverseLoginForm")
  const metaverseRegisterForm = document.getElementById("metaverseRegisterForm")
  const subscribeForm = document.getElementById("subscribeForm")

  if (metaverseLoginForm) {
    metaverseLoginForm.addEventListener("submit", (e) => {
      e.preventDefault()
      // Simulate login
      alert("Login successful! Redirecting to Metaverse...")
      metaverseModal.style.display = "none"
      // In a real app, you would redirect to the metaverse experience
    })
  }

  if (metaverseRegisterForm) {
    metaverseRegisterForm.addEventListener("submit", (e) => {
      e.preventDefault()
      // Simulate registration
      alert("Registration successful! You can now log in to the Metaverse.")
      registerModal.style.display = "none"
      metaverseModal.style.display = "flex"
    })
  }

  if (subscribeForm) {
    subscribeForm.addEventListener("submit", function (e) {
      e.preventDefault()
      const emailInput = this.querySelector('input[type="email"]')
      const subscribeMessage = document.getElementById("subscribeMessage")

      // Simulate subscription
      subscribeMessage.textContent = `Grazie! ${emailInput.value} è stato iscritto con successo.`
      subscribeMessage.style.color = "var(--success-color)"
      emailInput.value = ""

      setTimeout(() => {
        subscribeMessage.textContent = ""
      }, 5000)
    })
  }

  // Scroll Animations
  const animateOnScroll = () => {
    const elements = document.querySelectorAll(".fade-in, .fade-in-left, .fade-in-right, .stagger-item")

    elements.forEach((element) => {
      const elementPosition = element.getBoundingClientRect().top
      const windowHeight = window.innerHeight

      if (elementPosition < windowHeight - 100) {
        element.classList.add("visible")
      }
    })
  }

  window.addEventListener("scroll", animateOnScroll)
  animateOnScroll() // Run once on page load
})
