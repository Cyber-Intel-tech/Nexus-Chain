document.addEventListener("DOMContentLoaded", () => {
  // DNA 3D Animation
  const dnaModel = document.getElementById("dna-model")
  if (!dnaModel) return

  // Create DNA strands
  const strandCount = 2
  const nucleotidesPerStrand = 20
  const radius = 50
  const height = 400
  const rotationSpeed = 0.005

  let scene, camera, renderer
  const dna = new THREE.Object3D()

  // Initialize Three.js scene
  function initDNA() {
    // Create scene
    scene = new THREE.Scene()

    // Create camera
    camera = new THREE.PerspectiveCamera(75, dnaModel.clientWidth / dnaModel.clientHeight, 0.1, 1000)
    camera.position.z = 200

    // Create renderer
    renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true })
    renderer.setSize(dnaModel.clientWidth, dnaModel.clientHeight)
    renderer.setClearColor(0x000000, 0)
    dnaModel.appendChild(renderer.domElement)

    // Create DNA structure
    createDNAStructure()

    // Add DNA to scene
    scene.add(dna)

    // Add ambient light
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5)
    scene.add(ambientLight)

    // Add directional light
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1)
    directionalLight.position.set(1, 1, 1)
    scene.add(directionalLight)

    // Start animation
    animate()

    // Handle window resize
    window.addEventListener("resize", onWindowResize)
  }

  // Create DNA structure
  function createDNAStructure() {
    // Create DNA helix
    for (let i = 0; i < nucleotidesPerStrand; i++) {
      const ht = i * (height / nucleotidesPerStrand)
      const angle = i * 0.5

      // Create nucleotides
      for (let j = 0; j < strandCount; j++) {
        const strandAngle = angle + j * Math.PI
        const x = Math.cos(strandAngle) * radius
        const z = Math.sin(strandAngle) * radius

        // Create nucleotide (sphere)
        const nucleotideGeometry = new THREE.SphereGeometry(5, 16, 16)
        const nucleotideMaterial = new THREE.MeshPhongMaterial({
          color: j === 0 ? 0xffd700 : 0x00ffcc,
          emissive: j === 0 ? 0x996515 : 0x008080,
          shininess: 100,
          specular: 0xffffff,
        })

        const nucleotide = new THREE.Mesh(nucleotideGeometry, nucleotideMaterial)
        nucleotide.position.set(x, ht - height / 2, z)
        dna.add(nucleotide)

        // Create connection to opposite nucleotide
        if (j === 0) {
          const connectionGeometry = new THREE.CylinderGeometry(0.5, 0.5, radius * 2, 8)
          const connectionMaterial = new THREE.MeshPhongMaterial({
            color: 0xffffff,
            transparent: true,
            opacity: 0.5,
          })

          const connection = new THREE.Mesh(connectionGeometry, connectionMaterial)
          connection.position.set(0, ht - height / 2, 0)
          connection.rotation.z = Math.PI / 2
          connection.rotation.y = strandAngle + Math.PI / 2
          dna.add(connection)
        }

        // Create connection to next nucleotide in strand
        if (i < nucleotidesPerStrand - 1) {
          const nextHeight = (i + 1) * (height / nucleotidesPerStrand)
          const nextAngle = (i + 1) * 0.5
          const nextX = Math.cos(nextAngle + j * Math.PI) * radius
          const nextZ = Math.sin(nextAngle + j * Math.PI) * radius

          const dx = nextX - x
          const dy = nextHeight - height / 2 - (ht - height / 2)
          const dz = nextZ - z
          const distance = Math.sqrt(dx * dx + dy * dy + dz * dz)

          const strandGeometry = new THREE.CylinderGeometry(0.75, 0.75, distance, 8)
          const strandMaterial = new THREE.MeshPhongMaterial({
            color: j === 0 ? 0xffd700 : 0x00ffcc,
            transparent: true,
            opacity: 0.7,
          })

          const strand = new THREE.Mesh(strandGeometry, strandMaterial)

          // Position at midpoint
          strand.position.set(x + dx / 2, ht - height / 2 + dy / 2, z + dz / 2)

          // Orient along the connection
          strand.lookAt(new THREE.Vector3(nextX, nextHeight - height / 2, nextZ))
          strand.rotation.x += Math.PI / 2

          dna.add(strand)
        }
      }
    }
  }

  // Animation loop
  function animate() {
    requestAnimationFrame(animate)

    // Rotate DNA
    dna.rotation.y += rotationSpeed

    // Render scene
    renderer.render(scene, camera)
  }

  // Handle window resize
  function onWindowResize() {
    camera.aspect = dnaModel.clientWidth / dnaModel.clientHeight
    camera.updateProjectionMatrix()
    renderer.setSize(dnaModel.clientWidth, dnaModel.clientHeight)
  }

  // Initialize DNA animation
  initDNA()
})
