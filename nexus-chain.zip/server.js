const express = require("express")
const path = require("path")
const bodyParser = require("body-parser")
const session = require("express-session")
const bcrypt = require("bcryptjs")
const fs = require("fs")

// Initialize Express app
const app = express()
const PORT = process.env.PORT || 3000

// Middleware
app.use(express.static(path.join(__dirname, "public")))
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true }))
app.use(
  session({
    secret: "nexus-chain-secret",
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }, // Set to true if using HTTPS
  }),
)

// In-memory database (for demo purposes)
// In a real app, you would use a proper database like MongoDB or PostgreSQL
const users = []
const subscribers = []
const metaverseUsers = []

// Routes
// Home route
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"))
})

// Dashboard route (protected)
app.get("/dashboard", (req, res) => {
  if (req.session.user && req.session.user.isAdmin) {
    res.sendFile(path.join(__dirname, "public", "dashboard.html"))
  } else {
    res.redirect("/")
  }
})

// API Routes
// User registration
app.post("/api/register", async (req, res) => {
  try {
    const { username, email, password } = req.body

    // Check if user already exists
    if (users.find((user) => user.email === email)) {
      return res.status(400).json({ success: false, message: "User already exists" })
    }

    // Hash password
    const salt = await bcrypt.genSalt(10)
    const hashedPassword = await bcrypt.hash(password, salt)

    // Create new user
    const newUser = {
      id: users.length + 1,
      username,
      email,
      password: hashedPassword,
      isAdmin: false,
      createdAt: new Date(),
    }

    // Add user to database
    users.push(newUser)

    // Create session
    req.session.user = {
      id: newUser.id,
      username: newUser.username,
      email: newUser.email,
      isAdmin: newUser.isAdmin,
    }

    res.status(201).json({ success: true, user: req.session.user })
  } catch (error) {
    console.error(error)
    res.status(500).json({ success: false, message: "Server error" })
  }
})

// User login
app.post("/api/login", async (req, res) => {
  try {
    const { email, password } = req.body

    // Find user
    const user = users.find((user) => user.email === email)
    if (!user) {
      return res.status(400).json({ success: false, message: "Invalid credentials" })
    }

    // Check password
    const isMatch = await bcrypt.compare(password, user.password)
    if (!isMatch) {
      return res.status(400).json({ success: false, message: "Invalid credentials" })
    }

    // Create session
    req.session.user = {
      id: user.id,
      username: user.username,
      email: user.email,
      isAdmin: user.isAdmin,
    }

    res.json({ success: true, user: req.session.user })
  } catch (error) {
    console.error(error)
    res.status(500).json({ success: false, message: "Server error" })
  }
})

// User logout
app.get("/api/logout", (req, res) => {
  req.session.destroy()
  res.json({ success: true })
})

// Subscribe to newsletter
app.post("/api/subscribe", (req, res) => {
  try {
    const { email } = req.body

    // Check if email already exists
    if (subscribers.find((subscriber) => subscriber.email === email)) {
      return res.status(400).json({ success: false, message: "Email already subscribed" })
    }

    // Add email to subscribers
    subscribers.push({
      id: subscribers.length + 1,
      email,
      subscribedAt: new Date(),
    })

    res.status(201).json({ success: true, message: "Subscribed successfully" })
  } catch (error) {
    console.error(error)
    res.status(500).json({ success: false, message: "Server error" })
  }
})

// Metaverse user registration
app.post("/api/metaverse/register", async (req, res) => {
  try {
    const { username, email, password } = req.body

    // Check if user already exists
    if (metaverseUsers.find((user) => user.email === email)) {
      return res.status(400).json({ success: false, message: "User already exists" })
    }

    // Hash password
    const salt = await bcrypt.genSalt(10)
    const hashedPassword = await bcrypt.hash(password, salt)

    // Create new metaverse user
    const newUser = {
      id: metaverseUsers.length + 1,
      username,
      email,
      password: hashedPassword,
      createdAt: new Date(),
      lastLogin: new Date(),
    }

    // Add user to database
    metaverseUsers.push(newUser)

    res.status(201).json({ success: true, message: "Registered successfully" })
  } catch (error) {
    console.error(error)
    res.status(500).json({ success: false, message: "Server error" })
  }
})

// Metaverse user login
app.post("/api/metaverse/login", async (req, res) => {
  try {
    const { username, password } = req.body

    // Find user
    const user = metaverseUsers.find((user) => user.username === username)
    if (!user) {
      return res.status(400).json({ success: false, message: "Invalid credentials" })
    }

    // Check password
    const isMatch = await bcrypt.compare(password, user.password)
    if (!isMatch) {
      return res.status(400).json({ success: false, message: "Invalid credentials" })
    }

    // Update last login
    user.lastLogin = new Date()

    res.json({ success: true, message: "Logged in successfully" })
  } catch (error) {
    console.error(error)
    res.status(500).json({ success: false, message: "Server error" })
  }
})

// Admin routes (protected)
// Get all users
app.get("/api/admin/users", (req, res) => {
  if (!req.session.user || !req.session.user.isAdmin) {
    return res.status(401).json({ success: false, message: "Unauthorized" })
  }

  // Return users without passwords
  const safeUsers = users.map((user) => ({
    id: user.id,
    username: user.username,
    email: user.email,
    isAdmin: user.isAdmin,
    createdAt: user.createdAt,
  }))

  res.json({ success: true, users: safeUsers })
})

// Get all subscribers
app.get("/api/admin/subscribers", (req, res) => {
  if (!req.session.user || !req.session.user.isAdmin) {
    return res.status(401).json({ success: false, message: "Unauthorized" })
  }

  res.json({ success: true, subscribers })
})

// Create admin user if none exists
const createAdminUser = async () => {
  if (users.length === 0) {
    const salt = await bcrypt.genSalt(10)
    const hashedPassword = await bcrypt.hash("admin123", salt)

    users.push({
      id: 1,
      username: "admin",
      email: "admin@nexuschain.io",
      password: hashedPassword,
      isAdmin: true,
      createdAt: new Date(),
    })

    console.log("Admin user created")
  }
}

// Start server
app.listen(PORT, async () => {
  await createAdminUser()
  console.log(`Server running on port ${PORT}`)
})
